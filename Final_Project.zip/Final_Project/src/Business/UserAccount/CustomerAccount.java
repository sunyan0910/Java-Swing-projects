/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount;

import Business.AddressDirectory;
import Business.Enterprise.Enterprise;
import Business.Item;
import Business.OrderDirectory;
import Business.Role.Role;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author sunyan
 */
public class CustomerAccount {
    private String username;
    private String password;
    private Role role;
    private ArrayList<Item> cart;
    private AddressDirectory addressDir;
    private ImageIcon image;
    private OrderDirectory orderHistory;

    public CustomerAccount() {
        this.addressDir=new AddressDirectory();
        this.orderHistory=new OrderDirectory();
        this.cart=new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public AddressDirectory getAddressDir() {
        return addressDir;
    }

    public void setAddressDir(AddressDirectory addressDir) {
        this.addressDir = addressDir;
    }

    

    public ImageIcon getImage() {
        return image;
    }

    public void setImage(ImageIcon image) {
        this.image = image;
    }

    public OrderDirectory getOrderHistory() {
        return orderHistory;
    }

    public void setOrderHistory(OrderDirectory orderHistory) {
        this.orderHistory = orderHistory;
    }

    public ArrayList<Item> getCart() {
        return cart;
    }

    public void setCart(ArrayList<Item> cart) {
        this.cart = cart;
    }

    

    
    
    @Override
    public String toString() {
        return username;
    }
    
}
