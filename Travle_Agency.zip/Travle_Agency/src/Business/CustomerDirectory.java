/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class CustomerDirectory {
    private ArrayList<Customer> customerDirectory;

    public CustomerDirectory() {
        customerDirectory=new ArrayList<Customer>();
    }

    public ArrayList<Customer> getCustomerDirectory() {
        return customerDirectory;
    }
    public Customer addCustomer() {
        Customer c = new Customer();
        customerDirectory.add(c);
        return c;
    }
    
    public void removeCustomer(Customer c) {
        customerDirectory.remove(c);
    }
    public Customer searchCustomer(int id) {
        //ArrayList<Product> result = new ArrayList<Product>();
        for(Customer c : customerDirectory) {
            if(c.getModelNumber() == id) {
                return c;
            }
        }
        return null;
    }
}
