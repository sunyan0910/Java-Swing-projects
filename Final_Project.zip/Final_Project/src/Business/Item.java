/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import Business.Enterprise.Enterprise;
import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class Item {
    private String shopName;
    private Enterprise shop;
    private ArrayList<Product> productList;
    private int quantity;
    private float total;
    private int id;
    private static int count = 1;

    public Item() {
        id = count;
        count++;
        this.productList=new ArrayList<>();
        
    }

    public Enterprise getShop() {
        return shop;
    }

    public void setShop(Enterprise shop) {
        this.shop = shop;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public ArrayList<Product> getProductList() {
        return productList;
    }

    public void setProductList(ArrayList<Product> productList) {
        this.productList = productList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }
     @Override
    public String toString() {
        return shopName;
    }
}
