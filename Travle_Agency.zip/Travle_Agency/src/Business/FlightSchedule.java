/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class FlightSchedule {
    private ArrayList<Flight> flightSchedule;

    public FlightSchedule() {
        flightSchedule=new ArrayList<Flight>();
    }

    public ArrayList<Flight> getFlightSchedule() {
        return flightSchedule;
    }
    public Flight addFlight() {
        Flight f = new Flight();
        flightSchedule.add(f);
        return f;
    }
    
    public void removeFlight(Flight p) {
        flightSchedule.remove(p);
    }
    public Flight searchFlight(int id) {
        
        for(Flight f : flightSchedule) {
            if(f.getModelNumber() == id) {
                return f;
            }
        }
        return null;
    }
}
