/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author sunyan
 */
public class CommentDirectory {
    private ArrayList<Comment> commentDir;

    public CommentDirectory() {
        this.commentDir=new ArrayList();
    }

    public ArrayList<Comment> getCommentDir() {
        return commentDir;
    }

    public void setCommentDir(ArrayList<Comment> commentDir) {
        this.commentDir = commentDir;
    }
    public Comment createComment(Date date,String sender,String comment){
        Comment c = new Comment();
        c.setDate(date);
        c.setComment(comment);
        c.setSender(sender);
        commentDir.add(c);
        return c;
    }
}
