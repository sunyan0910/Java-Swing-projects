/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class AirlinerDirectory {
    private ArrayList<Airliner> airlinerDirectory;

    public AirlinerDirectory() {
        airlinerDirectory=new ArrayList<Airliner>();
    }

    public ArrayList<Airliner> getAirlinerDirectory() {
        return airlinerDirectory;
    }
    public Airliner addAirline() {
        Airliner a = new Airliner();
        airlinerDirectory.add(a);
        return a;
    }
    
    public void removeAirline(Airliner p) {
        airlinerDirectory.remove(p);
    }
    public Airliner searchAirliner(int id) {
        //ArrayList<Product> result = new ArrayList<Product>();
        for(Airliner a : airlinerDirectory) {
            if(a.getModelNumber() == id) {
                return a;
            }
        }
        return null;
    }
}
