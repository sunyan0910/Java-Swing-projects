/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserAccount;

import Business.AddressDirectory;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class CustomerAccountDirectory {
    private ArrayList<CustomerAccount> customerAccountList;

    public CustomerAccountDirectory() {
        customerAccountList = new ArrayList();
    }

    public ArrayList<CustomerAccount> getCustomerAccountList() {
        return customerAccountList;
    }

    
    
    public CustomerAccount authenticateUser(String username, String password){
        for (CustomerAccount ca : customerAccountList)
            if (ca.getUsername().equals(username) && ca.getPassword().equals(password)){
                return ca;
            }
        return null;
    }
    
    
    public boolean checkIfUsernameIsUnique(String username){
        for (CustomerAccount ca : customerAccountList){
            if (ca.getUsername().equals(username))
                return false;
        }
        return true;
    }
}
