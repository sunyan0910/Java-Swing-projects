/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Enterprise;



import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author sunyan
 */
public class ShopEnterprise extends Enterprise {
    
    
    public ShopEnterprise(String name){
        super(name,Enterprise.EnterpriseType.Shop);
        
    }
    
    @Override
    public ArrayList<Role> getSupportedRole() {
        return null;
    }

    
    
}
